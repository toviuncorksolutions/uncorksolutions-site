import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { irsSchema } from '../lib/irsSchema';
import type { IRSFormData } from '../lib/irsSchema';

// If you want to move this, import from a utils/hash.ts file instead
async function sha256(str: string): Promise<string> {
  const buf = await window.crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(str)
  );
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export function useIRSWaitlistForm() {
  const form = useForm<IRSFormData>({
    resolver: zodResolver(irsSchema),
    defaultValues: {
      firstName: '',
      lastName: '',
      email: '',
      challenge: '',
      outcome: '',
      obstacle: '',
      alternatives: '',
      lowPrice: undefined,
      highPrice: undefined,
      decisionAuthority: '',
      timeline: '',
    },
  });

  const submit = async (data: IRSFormData) => {
    const res = await fetch('/api/irs-waitlist', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Submit failed');

    (window as any).dataLayer = (window as any).dataLayer || [];
    const hash = await sha256(data.email);
    window.dataLayer.push({
      event: 'initiativeReadinessScanWaitlistFormSubmitted',
      emailHash: hash,
    });
  };

  return { form, submit };
}
