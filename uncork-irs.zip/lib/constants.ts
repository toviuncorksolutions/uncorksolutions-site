export const FREE_EMAIL_DOMAINS = [
  'gmail.com',
  'yahoo.com',
  'hotmail.com',
  'aol.com',
  'outlook.com',
  'icloud.com',
  'mail.com',
  'msn.com',
] as const;

export const SOFT_GREY_BG = 'bg-[#f1f2f4]';
